# Script de Otimização de GPO via Registro
# Replica as configurações manuais de Política de Grupo

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   APLICANDO POLÍTICAS DE GRUPO (GPO)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Função interna para facilitar a criação das chaves
function Set-GPORegistry {
    param ([string]$Path, [string]$Name, [int]$Value)
    
    if (-not (Test-Path $Path)) { 
        New-Item -Path $Path -Force | Out-Null
        Write-Host "      🔧 Criada chave: $Path" -ForegroundColor Gray
    }
    Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type DWord -Force
}

# Contador de sucessos
$totalConfigs = 0
$sucessos = 0

# ============================================
# 1. Coleta de Dados: Desativar Telemetria
# ============================================
Write-Host "[1/8] CONFIGURANDO TELEMETRIA E DIAGNÓSTICOS..." -ForegroundColor Yellow
try {
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Value 0
    Write-Host "      ✅ Telemetria desativada (AllowTelemetry = 0)" -ForegroundColor Green
    $sucessos++
} catch {
    Write-Host "      ❌ Falha ao configurar Telemetria" -ForegroundColor Red
}
$totalConfigs++
Write-Host ""

# ============================================
# 2. Compatibilidade: Desativar Mecanismo e Telemetria
# ============================================
Write-Host "[2/8] CONFIGURANDO COMPATIBILIDADE..." -ForegroundColor Yellow
try {
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Name "AITEnable" -Value 0
    Write-Host "      ✅ Telemetria de compatibilidade desativada (AITEnable = 0)" -ForegroundColor Green
    
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Name "DisableEngine" -Value 1
    Write-Host "      ✅ Mecanismo de compatibilidade desativado (DisableEngine = 1)" -ForegroundColor Green
    $sucessos++
} catch {
    Write-Host "      ❌ Falha ao configurar Compatibilidade" -ForegroundColor Red
}
$totalConfigs++
Write-Host ""

# ============================================
# 3. Conteúdo em Nuvem: Desativar sugestões
# ============================================
Write-Host "[3/8] CONFIGURANDO CONTEÚDO EM NUVEM..." -ForegroundColor Yellow
try {
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableWindowsConsumerFeatures" -Value 1
    Write-Host "      ✅ Recursos de consumidor desativados (DisableWindowsConsumerFeatures = 1)" -ForegroundColor Green
    
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableCloudOptimizedContent" -Value 1
    Write-Host "      ✅ Conteúdo otimizado em nuvem desativado (DisableCloudOptimizedContent = 1)" -ForegroundColor Green
    $sucessos++
} catch {
    Write-Host "      ❌ Falha ao configurar Conteúdo em Nuvem" -ForegroundColor Red
}
$totalConfigs++
Write-Host ""

# ============================================
# 4. Sensores: Desativar Localização
# ============================================
Write-Host "[4/8] CONFIGURANDO SENSORES E LOCALIZAÇÃO..." -ForegroundColor Yellow
try {
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" -Name "DisableLocation" -Value 1
    Write-Host "      ✅ Serviço de localização desativado (DisableLocation = 1)" -ForegroundColor Green
    $sucessos++
} catch {
    Write-Host "      ❌ Falha ao configurar Localização" -ForegroundColor Red
}
$totalConfigs++
Write-Host ""

# ============================================
# 5. Pesquisa: Desativar Cortana e Pesquisa Web
# ============================================
Write-Host "[5/8] CONFIGURANDO PESQUISA E CORTANA..." -ForegroundColor Yellow
try {
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search" -Name "AllowCortana" -Value 0
    Write-Host "      ✅ Cortana desativada (AllowCortana = 0)" -ForegroundColor Green
    
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search" -Name "DisableWebSearch" -Value 1
    Write-Host "      ✅ Pesquisa na web desativada (DisableWebSearch = 1)" -ForegroundColor Green
    
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search" -Name "ConnectedSearchUseWeb" -Value 0
    Write-Host "      ✅ Pesquisa conectada desativada (ConnectedSearchUseWeb = 0)" -ForegroundColor Green
    $sucessos++
} catch {
    Write-Host "      ❌ Falha ao configurar Pesquisa e Cortana" -ForegroundColor Red
}
$totalConfigs++
Write-Host ""

# ============================================
# 6. Privacidade: Forçar negação de apps em segundo plano
# ============================================
Write-Host "[6/8] CONFIGURANDO PRIVACIDADE DE APPS..." -ForegroundColor Yellow
try {
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" -Name "LetAppsRunInBackground" -Value 2
    Write-Host "      ✅ Apps bloqueados em segundo plano (LetAppsRunInBackground = 2)" -ForegroundColor Green
    $sucessos++
} catch {
    Write-Host "      ❌ Falha ao configurar Privacidade de Apps" -ForegroundColor Red
}
$totalConfigs++
Write-Host ""

# ============================================
# 7. Relatórios de Erro: Desabilitar envio
# ============================================
Write-Host "[7/8] CONFIGURANDO RELATÓRIOS DE ERRO..." -ForegroundColor Yellow
try {
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsErrorReporting" -Name "Disabled" -Value 1
    Write-Host "      ✅ Relatórios de erro desativados (Disabled = 1)" -ForegroundColor Green
    $sucessos++
} catch {
    Write-Host "      ❌ Falha ao configurar Relatórios de Erro" -ForegroundColor Red
}
$totalConfigs++
Write-Host ""

# ============================================
# 8. Windows Update: Avisar antes de baixar
# ============================================
Write-Host "[8/8] CONFIGURANDO WINDOWS UPDATE..." -ForegroundColor Yellow
try {
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "NoAutoUpdate" -Value 0
    Write-Host "      ✅ Atualizações automáticas habilitadas (NoAutoUpdate = 0)" -ForegroundColor Green
    
    Set-GPORegistry -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "AUOptions" -Value 2
    Write-Host "      ✅ Notificar antes de baixar (AUOptions = 2)" -ForegroundColor Green
    $sucessos++
} catch {
    Write-Host "      ❌ Falha ao configurar Windows Update" -ForegroundColor Red
}
$totalConfigs++
Write-Host ""

# ============================================
# RESUMO FINAL
# ============================================
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "            RESUMO FINAL" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if ($sucessos -eq $totalConfigs) {
    Write-Host "  ✅ TODAS AS CONFIGURAÇÕES FORAM APLICADAS COM SUCESSO!" -ForegroundColor Green
} else {
    Write-Host "  ⚠️  CONFIGURAÇÕES APLICADAS: $sucessos de $totalConfigs" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "  Configurações aplicadas:" -ForegroundColor White
Write-Host "    1. ✅ Telemetria e diagnósticos desativados" -ForegroundColor Gray
Write-Host "    2. ✅ Compatibilidade e telemetria de apps desativada" -ForegroundColor Gray
Write-Host "    3. ✅ Conteúdo em nuvem e sugestões desativadas" -ForegroundColor Gray
Write-Host "    4. ✅ Serviço de localização desativado" -ForegroundColor Gray
Write-Host "    5. ✅ Cortana e pesquisa na web desativadas" -ForegroundColor Gray
Write-Host "    6. ✅ Apps bloqueados em segundo plano" -ForegroundColor Gray
Write-Host "    7. ✅ Relatórios de erro desativados" -ForegroundColor Gray
Write-Host "    8. ✅ Windows Update configurado para notificar" -ForegroundColor Gray

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ============================================
# PAUSA PARA CONFIRMAÇÃO
# ============================================
Write-Host "As políticas de grupo foram aplicadas com sucesso!" -ForegroundColor Green
Write-Host ""
Write-Host "Pressione ENTER para continuar..." -ForegroundColor Yellow
Read-Host

# ============================================
# REINICIALIZAÇÃO OPCIONAL
# ============================================
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Para que todas as alterações tenham efeito," -ForegroundColor White
Write-Host "é necessário reiniciar o computador." -ForegroundColor White
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$reiniciar = Read-Host "Deseja reiniciar o computador agora? (S/N)"

if ($reiniciar -eq 'S' -or $reiniciar -eq 's') {
    Write-Host ""
    Write-Host "Reiniciando o computador em 5 segundos..." -ForegroundColor Yellow
    Start-Sleep -Seconds 5
    Restart-Computer -Force
} else {
    Write-Host ""
    Write-Host "Lembre-se de reiniciar o computador manualmente mais tarde para aplicar todas as alterações." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Pressione qualquer tecla para sair..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}