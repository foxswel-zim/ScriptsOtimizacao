net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Solicitei acesso de administrador...
    powershell start -verb runas '%0'
    exit /b
)

@echo off
title Associar PowerShell para arquivos .ps1
color 0F

cls
echo ========================================
echo    ASSOCIANDO .PS1 AO POWERSHELL
echo ========================================
echo.

REM Verifica se é administrador
echo [VERIFICANDO PERMISSOES]...
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo.
    echo [ERRO] Este script requer privilegios de administrador!
    echo.
    echo Clique com botao direito e selecione "Executar como administrador"
    echo.
    echo Pressione qualquer tecla para sair...
    pause > nul
    exit /b 1
)
echo [OK] Permissoes de administrador confirmadas.
echo.

REM Associa arquivos .ps1
echo [CRIANDO ASSOCIACAO]...
echo   >> Adicionando chave .ps1...
reg add "HKCR\.ps1" /ve /d "Microsoft.PowerShellScript.1" /f >nul 2>&1
if %errorLevel% equ 0 ( echo   [OK] Chave .ps1 criada ) else ( echo   [FALHA] Erro ao criar chave .ps1 )

echo   >> Adicionando comando de abertura...
reg add "HKCR\Microsoft.PowerShellScript.1\Shell\Open\Command" /ve /d "\"C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe\" -File \"%1\"" /f >nul 2>&1
if %errorLevel% equ 0 ( echo   [OK] Comando de abertura configurado ) else ( echo   [FALHA] Erro ao configurar comando )
echo.

REM Configura política de execução
echo [CONFIGURANDO POLITICA DE EXECUCAO]...
reg add "HKLM\SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.PowerShell" /v "ExecutionPolicy" /d "RemoteSigned" /f >nul 2>&1
if %errorLevel% equ 0 (
    echo   [OK] Politica de execucao configurada para: RemoteSigned
) else (
    echo   [FALHA] Erro ao configurar politica de execucao
)
echo.

REM Opção para PowerShell 7 (se instalado)
echo [VERIFICANDO POWERSHELL 7]...
if exist "C:\Program Files\PowerShell\7\pwsh.exe" (
    echo   [INFO] PowerShell 7 detectado!
    echo   >> Adicionando associacao para PowerShell 7...
    reg add "HKCR\Microsoft.PowerShellScript.1\Shell\Open\Command\PowerShell7" /ve /d "\"C:\\Program Files\\PowerShell\\7\\pwsh.exe\" -File \"%1\"" /f >nul 2>&1
    echo   [OK] Associacao para PowerShell 7 criada
) else (
    echo   [INFO] PowerShell 7 nao detectado (opcional)
)
echo.

echo ========================================
echo    CONCLUIDO COM SUCESSO!
echo ========================================
echo.
echo  O que foi feito:
echo    ✅ Arquivos .ps1 associados ao PowerShell
echo    ✅ Duplo clique executara scripts .ps1
echo    ✅ Politica de execucao: RemoteSigned
echo.
echo  Como testar:
echo    Crie um arquivo .ps1 com: Write-Host "Teste"
echo    De duplo clique nele
echo.
echo ========================================
echo.
echo Pressione ENTER para fechar...
pause > nul
exit /b 0