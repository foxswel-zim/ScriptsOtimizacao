# Script para reinstalar a Microsoft Store
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  REINSTALANDO A MICROSOFT STORE" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 1. Tentativa com wsreset -i
Write-Host "[1/3] Tentando método wsreset -i..." -ForegroundColor Yellow
Start-Process -FilePath "wsreset.exe" -ArgumentList "-i" -NoNewWindow -Wait
Write-Host "Comando executado. Aguardando 5 segundos..." -ForegroundColor Gray
Start-Sleep -Seconds 5

# 2. Verificar se a Store já foi reinstalada
$store = Get-AppxPackage -Name "Microsoft.WindowsStore"
if ($store) {
    Write-Host "[SUCESSO] Microsoft Store já está instalada!" -ForegroundColor Green
    Write-Host "Versão: $($store.Version)" -ForegroundColor Gray
} else {
    Write-Host "[2/3] Tentando reinstalar via PowerShell..." -ForegroundColor Yellow
    
    # Tentativa com o comando padrão
    $command = Get-AppxPackage -allusers Microsoft.WindowsStore | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
    
    # Se falhar, tenta a versão com todos os apps
    if (-not (Get-AppxPackage -Name "Microsoft.WindowsStore")) {
        Write-Host "Tentando método alternativo..." -ForegroundColor Yellow
        Get-AppxPackage -AllUsers | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
    }
}

# 3. Verificação final
Write-Host ""
Write-Host "[3/3] Verificando instalação..." -ForegroundColor Yellow
Start-Sleep -Seconds 3

$storeFinal = Get-AppxPackage -Name "Microsoft.WindowsStore"
if ($storeFinal) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  MICROSOFT STORE REINSTALADA COM SUCESSO!" -ForegroundColor Green
    Write-Host "  Versão: $($storeFinal.Version)" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Recomendação: Reinicie o computador para garantir que tudo funcione corretamente." -ForegroundColor Yellow
    
    $reiniciar = Read-Host "Deseja reiniciar agora? (S/N)"
    if ($reiniciar -eq 'S' -or $reiniciar -eq 's') {
        Restart-Computer -Force
    }
} else {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "  FALHA NA REINSTALAÇÃO DA MICROSOFT STORE" -ForegroundColor Red
    Write-Host "========================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Possíveis soluções:" -ForegroundColor Yellow
    Write-Host "1. Execute o PowerShell como Administrador" -ForegroundColor Gray
    Write-Host "2. Verifique sua conexão com a internet" -ForegroundColor Gray
    Write-Host "3. Execute o comando manualmente: wsreset -i" -ForegroundColor Gray
    Write-Host "4. Considere reparar a instalação do Windows" -ForegroundColor Gray
}