net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Solicitei acesso de administrador...
    powershell start -verb runas '%0'
    exit /b
)

@echo off
title Desinstalar Microsoft Edge
color 0C

echo ========================================
echo    DESINSTALANDO MICROSOFT EDGE
echo ========================================
echo.

echo [1/4] Verificando permissoes de administrador...
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo       ❌ ERRO: Execute este script como Administrador!
    echo.
    echo       Clique com botao direito e selecione "Executar como administrador"
    echo.
    pause
    exit /b 1
)
echo       ✅ Permissoes de administrador OK!
echo.

echo [2/4] Localizando instalacao do Microsoft Edge...
cd "C:\Program Files (x86)\Microsoft\Edge\Application\*\Installer" 2>nul
if %errorLevel% neq 0 (
    cd "C:\Program Files\Microsoft\Edge\Application\*\Installer" 2>nul
)
if %errorLevel% neq 0 (
    echo       ❌ Instalacao do Edge nao encontrada!
    echo.
    pause
    exit /b 1
)
echo       ✅ Instalacao localizada!
echo.

echo [3/4] Desinstalando Microsoft Edge...
setup --uninstall --force-uninstall --system-level >nul 2>&1
if %errorLevel% equ 0 (
    echo       ✅ Desinstalacao concluida!
) else (
    echo       ⚠️  Tentando metodo alternativo...
    setup --uninstall --force-uninstall >nul 2>&1
)
echo.

echo [4/4] Removendo arquivos residuais...
rmdir /S /Q "C:\Program Files (x86)\Microsoft\Edge" 2>nul
rmdir /S /Q "C:\Program Files\Microsoft\Edge" 2>nul
rmdir /S /Q "%LOCALAPPDATA%\Microsoft\Edge" 2>nul
rmdir /S /Q "%APPDATA%\Microsoft\Edge" 2>nul
echo       ✅ Arquivos residuais removidos!
echo.

echo ========================================
echo    DESINSTALACAO CONCLUIDA!
echo ========================================
echo.
echo  ✅ Microsoft Edge foi removido do sistema
echo  ✅ Recomenda-se reiniciar o computador
echo.

echo ========================================
echo Pressione ENTER para fechar...
pause > nul
exit /b 0